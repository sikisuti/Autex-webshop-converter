const arrConstants = [
    [1, 'simple'],
    [4, '1'],
    [5, '0'],
    [6, 'visible'],
    [11, 'taxable'],
    [16, '0'],
    [17, '0'],
    [22, '1'],
    [38, '0']
]


export let constants = new Map(arrConstants);