class Another {
    constructor() {}

    convert() {
        alert('another converts');
    }
}

export { Another };